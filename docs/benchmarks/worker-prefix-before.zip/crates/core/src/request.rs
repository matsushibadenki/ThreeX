//! Persistent identifiers and bounded request receipts, independent of hosts.
use crate::{Document, DocumentError, PreparedTransaction};
use std::{
    collections::{BTreeMap, VecDeque},
    fmt,
    str::FromStr,
};
macro_rules! identifier {
    ($name:ident) => {
        #[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
        pub struct $name([u8; 16]);
        impl $name {
            pub fn from_bytes(bytes: [u8; 16]) -> Option<Self> {
                (bytes != [0; 16]).then_some(Self(bytes))
            }
            pub fn bytes(self) -> [u8; 16] {
                self.0
            }
        }
        impl fmt::Display for $name {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                for b in self.0 {
                    write!(f, "{b:02x}")?
                }
                Ok(())
            }
        }
        impl FromStr for $name {
            type Err = ();
            fn from_str(s: &str) -> Result<Self, ()> {
                if s.len() != 32 || !s.is_ascii() {
                    return Err(());
                }
                let mut b = [0; 16];
                for (i, v) in b.iter_mut().enumerate() {
                    *v = u8::from_str_radix(&s[i * 2..i * 2 + 2], 16).map_err(|_| ())?
                }
                Self::from_bytes(b).ok_or(())
            }
        }
    };
}
identifier!(DocumentId);
identifier!(SessionId);
#[derive(Debug, PartialEq, Eq)]
pub enum RequestError {
    DocumentMismatch,
    InvalidSequence,
    SequenceGap,
    Expired,
    Mismatch,
    SessionLimit,
    Edit(DocumentError),
}
#[derive(Clone)]
pub(crate) struct Receipt {
    pub session: SessionId,
    pub sequence: u64,
    pub kind: u8,
    pub expected: u64,
    pub revision: u64,
    pub commands: Vec<u8>,
}
#[derive(Default)]
pub(crate) struct RequestLedger {
    pub sessions: BTreeMap<SessionId, u64>,
    pub receipts: VecDeque<Receipt>,
    pub bytes: usize,
}
pub enum RequestPreparation {
    Replay(u64),
    Pending(PreparedRequest),
}
pub struct PreparedRequest {
    edit: PreparedTransaction,
    receipt: Receipt,
    prior: u64,
    document: DocumentId,
}
impl PreparedRequest {
    pub fn revision(&self) -> u64 {
        self.receipt.revision
    }
}
impl Document {
    pub fn session_sequence(&self, session: SessionId) -> Option<u64> {
        self.ledger.sessions.get(&session).copied()
    }
    pub fn request_generation(&self) -> u128 {
        self.ledger.sessions.values().map(|&n| n as u128).sum()
    }
    pub fn document_id(&self) -> Option<DocumentId> {
        self.id
    }
    /// Hosts bind draft/legacy documents once, before exposing their persistent identity.
    pub fn bind_document_id(&mut self, id: DocumentId) -> Result<(), RequestError> {
        if self.id.is_some_and(|old| old != id) {
            return Err(RequestError::DocumentMismatch);
        }
        self.id = Some(id);
        Ok(())
    }
    pub fn prepare_request(
        &self,
        document: DocumentId,
        session: SessionId,
        sequence: u64,
        kind: u8,
        expected: u64,
        commands: &[u8],
    ) -> Result<RequestPreparation, RequestError> {
        if self.id != Some(document) {
            return Err(RequestError::DocumentMismatch);
        }
        if sequence == 0 {
            return Err(RequestError::InvalidSequence);
        }
        let prior = self.ledger.sessions.get(&session).copied().unwrap_or(0);
        if sequence <= prior {
            let Some(receipt) = self
                .ledger
                .receipts
                .iter()
                .find(|r| r.session == session && r.sequence == sequence)
            else {
                return Err(RequestError::Expired);
            };
            if receipt.kind != kind || receipt.expected != expected || receipt.commands != commands
            {
                return Err(RequestError::Mismatch);
            }
            return Ok(RequestPreparation::Replay(receipt.revision));
        }
        if prior.checked_add(1) != Some(sequence) {
            return Err(RequestError::SequenceGap);
        }
        if prior == 0 && self.ledger.sessions.len() >= 64 {
            return Err(RequestError::SessionLimit);
        }
        let edit = match kind {
            1 => self.prepare_commit(expected, commands),
            2 if commands.is_empty() => self.prepare_undo(expected),
            3 if commands.is_empty() => self.prepare_redo(expected),
            _ => {
                return Err(RequestError::Edit(DocumentError::InvalidCommand(
                    "Unknown request kind".into(),
                )));
            }
        }
        .map_err(RequestError::Edit)?;
        let receipt = Receipt {
            session,
            sequence,
            kind,
            expected,
            revision: edit.revision(),
            commands: commands.to_vec(),
        };
        Ok(RequestPreparation::Pending(PreparedRequest {
            edit,
            receipt,
            prior,
            document,
        }))
    }
    pub fn apply_request(&mut self, prepared: PreparedRequest) -> Result<u64, RequestError> {
        if self.id != Some(prepared.document) {
            return Err(RequestError::DocumentMismatch);
        }
        if self
            .ledger
            .sessions
            .get(&prepared.receipt.session)
            .copied()
            .unwrap_or(0)
            != prepared.prior
        {
            return Err(RequestError::Expired);
        }
        let revision = self
            .apply_prepared(prepared.edit)
            .map_err(RequestError::Edit)?;
        self.ledger
            .sessions
            .insert(prepared.receipt.session, prepared.receipt.sequence);
        self.ledger.bytes += prepared.receipt.commands.len();
        self.ledger.receipts.push_back(prepared.receipt);
        while self.ledger.receipts.len() > 64 || self.ledger.bytes > 8 * 1024 * 1024 {
            self.ledger.bytes -= self.ledger.receipts.pop_front().unwrap().commands.len();
        }
        Ok(revision)
    }
}

/// Borrowed commit envelope. Group validation stages only deltas and bounded ledger metadata.
pub struct RequestCommit<'a> {
    pub document: DocumentId,
    pub session: SessionId,
    pub sequence: u64,
    pub expected: u64,
    pub commands: &'a [u8],
}
/// Opaque preparation tied to both scene state and durable request watermarks.
pub struct PreparedRequestGroup {
    document: DocumentId,
    generation: u128,
    edits: Option<crate::PreparedGroup>,
    receipts: Vec<Receipt>,
    results: Vec<(u64, bool)>,
}
impl PreparedRequestGroup {
    /// One (original revision, replayed) result per input, in input order.
    pub fn results(&self) -> &[(u64, bool)] {
        &self.results
    }
}
impl Document {
    /// At most 32 commits / 1 MiB. Any invalid envelope rejects the explicit group.
    /// Undo and Redo are barriers handled by prepare_request instead.
    pub fn prepare_request_group(
        &self,
        requests: &[RequestCommit<'_>],
    ) -> Result<PreparedRequestGroup, RequestError> {
        if requests.len() > 32
            || requests.iter().map(|r| r.commands.len()).sum::<usize>() > 1024 * 1024
        {
            return Err(RequestError::Edit(DocumentError::CommandTooLarge));
        }
        let document = self.id.ok_or(RequestError::DocumentMismatch)?;
        // Borrow existing payloads: no Document, history, or receipt-payload cloning.
        struct View<'a> {
            session: SessionId,
            sequence: u64,
            kind: u8,
            expected: u64,
            commands: &'a [u8],
            result: Result<u64, usize>,
        }
        let mut recent = self
            .ledger
            .receipts
            .iter()
            .map(|r| View {
                session: r.session,
                sequence: r.sequence,
                kind: r.kind,
                expected: r.expected,
                commands: &r.commands,
                result: Ok(r.revision),
            })
            .collect::<VecDeque<_>>();
        let mut sessions = self.ledger.sessions.clone();
        let mut bytes = self.ledger.bytes;
        let mut pending = Vec::new();
        let mut outcomes = Vec::new();
        for r in requests {
            if r.document != document {
                return Err(RequestError::DocumentMismatch);
            }
            if r.sequence == 0 {
                return Err(RequestError::InvalidSequence);
            }
            let prior = sessions.get(&r.session).copied().unwrap_or(0);
            if r.sequence <= prior {
                let old = recent
                    .iter()
                    .find(|old| old.session == r.session && old.sequence == r.sequence)
                    .ok_or(RequestError::Expired)?;
                if old.kind != 1 || old.expected != r.expected || old.commands != r.commands {
                    return Err(RequestError::Mismatch);
                }
                outcomes.push((old.result, true));
                continue;
            }
            if prior.checked_add(1) != Some(r.sequence) {
                return Err(RequestError::SequenceGap);
            }
            if prior == 0 && sessions.len() >= 64 {
                return Err(RequestError::SessionLimit);
            }
            let index = pending.len();
            pending.push(r);
            outcomes.push((Err(index), false));
            sessions.insert(r.session, r.sequence);
            recent.push_back(View {
                session: r.session,
                sequence: r.sequence,
                kind: 1,
                expected: r.expected,
                commands: r.commands,
                result: Err(index),
            });
            bytes += r.commands.len();
            while recent.len() > 64 || bytes > 8 * 1024 * 1024 {
                bytes -= recent.pop_front().unwrap().commands.len();
            }
        }
        let edits = if pending.is_empty() {
            None
        } else {
            let commands = pending.iter().map(|r| r.commands).collect::<Vec<_>>();
            let expected = pending.iter().map(|r| r.expected).collect::<Vec<_>>();
            Some(
                self.prepare_group_expected(self.revision(), &commands, Some(&expected))
                    .map_err(RequestError::Edit)?,
            )
        };
        let revisions = edits.as_ref().map(|e| e.revisions()).unwrap_or_default();
        let receipts = pending
            .iter()
            .zip(&revisions)
            .map(|(r, &revision)| Receipt {
                session: r.session,
                sequence: r.sequence,
                kind: 1,
                expected: r.expected,
                revision,
                commands: r.commands.to_vec(),
            })
            .collect();
        let results = outcomes
            .into_iter()
            .map(|(result, replayed)| (result.unwrap_or_else(|index| revisions[index]), replayed))
            .collect();
        Ok(PreparedRequestGroup {
            document,
            generation: self.request_generation(),
            edits,
            receipts,
            results,
        })
    }
    pub fn apply_request_group(
        &mut self,
        group: PreparedRequestGroup,
    ) -> Result<Vec<(u64, bool)>, RequestError> {
        if self.id != Some(group.document) {
            return Err(RequestError::DocumentMismatch);
        }
        if self.request_generation() != group.generation {
            return Err(RequestError::Expired);
        }
        if let Some(edits) = group.edits {
            self.apply_group(edits).map_err(RequestError::Edit)?;
        }
        for receipt in group.receipts {
            self.ledger
                .sessions
                .insert(receipt.session, receipt.sequence);
            self.ledger.bytes += receipt.commands.len();
            self.ledger.receipts.push_back(receipt);
            while self.ledger.receipts.len() > 64 || self.ledger.bytes > 8 * 1024 * 1024 {
                self.ledger.bytes -= self.ledger.receipts.pop_front().unwrap().commands.len();
            }
        }
        Ok(group.results)
    }
}

#[cfg(test)]
mod group_tests {
    use super::*;
    fn draft() -> (Document, DocumentId, SessionId) {
        let mut d = Document::default();
        let id = DocumentId::from_bytes([1; 16]).unwrap();
        d.bind_document_id(id).unwrap();
        (d, id, SessionId::from_bytes([2; 16]).unwrap())
    }
    #[test]
    fn grouped_noops_guard_metadata_and_reject_invalid_groups_without_changes() {
        let (mut d, id, session) = draft();
        let make = |sequence| RequestCommit {
            document: id,
            session,
            sequence,
            expected: 0,
            commands: &[],
        };
        let group = d
            .prepare_request_group(&[make(1), make(2), make(1)])
            .unwrap();
        assert_eq!(group.results(), &[(0, false), (0, false), (0, true)]);
        let stale = d.prepare_request_group(&[make(1)]).unwrap();
        d.apply_request_group(group).unwrap();
        assert_eq!(d.revision(), 0);
        assert!(matches!(
            d.apply_request_group(stale),
            Err(RequestError::Expired)
        ));
        assert!(matches!(
            d.prepare_request_group(&[make(3), make(5)]),
            Err(RequestError::SequenceGap)
        ));
        assert_eq!(d.session_sequence(session), Some(2));
        assert!(matches!(
            d.prepare_request_group(&(0..33).map(|_| make(1)).collect::<Vec<_>>()),
            Err(RequestError::Edit(DocumentError::CommandTooLarge))
        ));
        let bytes = vec![0; 1024 * 1024 + 64];
        assert!(matches!(
            d.prepare_request_group(&[RequestCommit {
                commands: &bytes,
                ..make(3)
            }]),
            Err(RequestError::Edit(DocumentError::CommandTooLarge))
        ));
    }
    #[test]
    fn virtual_receipt_eviction_matches_sequential_requests() {
        let (mut d, id, session) = draft();
        for sequence in 1..=64 {
            let RequestPreparation::Pending(p) =
                d.prepare_request(id, session, sequence, 1, 0, &[]).unwrap()
            else {
                panic!()
            };
            d.apply_request(p).unwrap();
        }
        let input = |sequence| RequestCommit {
            document: id,
            session,
            sequence,
            expected: 0,
            commands: &[],
        };
        assert!(matches!(
            d.prepare_request_group(&[input(65), input(1)]),
            Err(RequestError::Expired)
        ));
        assert_eq!(d.session_sequence(session), Some(64));
        let group = d.prepare_request_group(&[input(65), input(2)]).unwrap();
        assert_eq!(
            d.apply_request_group(group).unwrap(),
            vec![(0, false), (0, true)]
        );
        let mut restored = Document::from_checkpoint(&d.checkpoint().unwrap()).unwrap();
        assert!(matches!(
            restored.prepare_request(id, session, 1, 1, 0, &[]),
            Err(RequestError::Expired)
        ));
        let group = restored.prepare_request_group(&[input(65)]).unwrap();
        assert_eq!(
            restored.apply_request_group(group).unwrap(),
            vec![(0, true)]
        );
    }
    #[test]
    fn group_preparation_is_bound_to_scene_identity_and_session_capacity() {
        let (mut d, id, session) = draft();
        let mut command = [0; 64];
        command[..4].copy_from_slice(&1u32.to_le_bytes());
        command[4..8].copy_from_slice(&1u32.to_le_bytes());
        let input = RequestCommit {
            document: id,
            session,
            sequence: 1,
            expected: 0,
            commands: &command,
        };
        let group = d.prepare_request_group(&[input]).unwrap();
        let mut other = Document::from_checkpoint(&d.checkpoint().unwrap()).unwrap();
        assert!(matches!(
            other.apply_request_group(group),
            Err(RequestError::Edit(DocumentError::RevisionConflict { .. }))
        ));
        assert_eq!(other.request_generation(), 0);
        for n in 1..=63 {
            let session = SessionId::from_bytes([n; 16]).unwrap();
            let group = d
                .prepare_request_group(&[RequestCommit {
                    document: id,
                    session,
                    sequence: 1,
                    expected: 0,
                    commands: &[],
                }])
                .unwrap();
            d.apply_request_group(group).unwrap();
        }
        let candidate = [64, 65].map(|n| RequestCommit {
            document: id,
            session: SessionId::from_bytes([n; 16]).unwrap(),
            sequence: 1,
            expected: 0,
            commands: &[],
        });
        assert!(matches!(
            d.prepare_request_group(&candidate),
            Err(RequestError::SessionLimit)
        ));
        assert_eq!(d.ledger.sessions.len(), 63);
        let mut wrong = RequestCommit {
            document: DocumentId::from_bytes([9; 16]).unwrap(),
            session,
            sequence: 2,
            expected: 0,
            commands: &[],
        };
        assert!(matches!(
            d.prepare_request_group(&[wrong]),
            Err(RequestError::DocumentMismatch)
        ));
        wrong = RequestCommit {
            document: id,
            session,
            sequence: 0,
            expected: 0,
            commands: &[],
        };
        assert!(matches!(
            d.prepare_request_group(&[wrong]),
            Err(RequestError::InvalidSequence)
        ));
    }
}
