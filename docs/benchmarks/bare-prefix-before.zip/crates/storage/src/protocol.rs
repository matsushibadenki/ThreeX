use crate::*;
use threex_core::{DocumentId, SessionId};
pub const REQUEST_PROTOCOL_VERSION: u32 = 1;
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ProtocolAction {
    Commit {
        expected_revision: u64,
        commands: Vec<u8>,
    },
    Undo {
        expected_revision: u64,
    },
    Redo {
        expected_revision: u64,
    },
}
impl ProtocolAction {
    pub(crate) fn parts(&self) -> (u8, u64, &[u8]) {
        match self {
            Self::Commit {
                expected_revision,
                commands,
            } => (1, *expected_revision, commands),
            Self::Undo { expected_revision } => (2, *expected_revision, &[]),
            Self::Redo { expected_revision } => (3, *expected_revision, &[]),
        }
    }
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ProtocolRequest {
    pub protocol_version: u32,
    pub document_id: DocumentId,
    pub session_id: SessionId,
    pub sequence: u64,
    pub action: ProtocolAction,
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ProtocolReceipt {
    pub revision: u64,
    pub replayed: bool,
}
impl AutosaveDocument {
    pub fn request(&mut self, request: &ProtocolRequest) -> Result<ProtocolReceipt, StorageError> {
        self.request_with(request, |_| Ok(()))
    }
}

pub(crate) fn push_protocol_candidate(
    builder: &mut threex_core::RequestGroupBuilder<'_>,
    request: &ProtocolRequest,
) -> Result<(u64, bool), StorageError> {
    if request.protocol_version != REQUEST_PROTOCOL_VERSION {
        return Err(StorageError::UnsupportedRequestProtocol);
    }
    let ProtocolAction::Commit {
        expected_revision,
        commands,
    } = &request.action
    else {
        return Err(StorageError::Edit(
            threex_core::DocumentError::InvalidCommand(
                "Undo/Redo require a request barrier".into(),
            ),
        ));
    };
    builder
        .push(&threex_core::RequestCommit {
            document: request.document_id,
            session: request.session_id,
            sequence: request.sequence,
            expected: *expected_revision,
            commands,
        })
        .map_err(StorageError::Request)
}
/// Prepare commit envelopes only; Undo/Redo are explicit batching barriers.
pub(crate) fn prepare_protocol_group(
    document: &threex_core::Document,
    requests: &[&ProtocolRequest],
) -> Result<threex_core::PreparedRequestGroup, StorageError> {
    let mut input = Vec::with_capacity(requests.len().min(32));
    if requests.len() > 32 {
        return Err(StorageError::Edit(
            threex_core::DocumentError::CommandTooLarge,
        ));
    }
    for r in requests {
        if r.protocol_version != REQUEST_PROTOCOL_VERSION {
            return Err(StorageError::UnsupportedRequestProtocol);
        }
        let ProtocolAction::Commit {
            expected_revision,
            commands,
        } = &r.action
        else {
            return Err(StorageError::Edit(
                threex_core::DocumentError::InvalidCommand(
                    "Undo/Redo require a request barrier".into(),
                ),
            ));
        };
        input.push(threex_core::RequestCommit {
            document: r.document_id,
            session: r.session_id,
            sequence: r.sequence,
            expected: *expected_revision,
            commands,
        });
    }
    document
        .prepare_request_group(&input)
        .map_err(StorageError::Request)
}
impl AutosaveDocument {
    /// Commit up to 32 request envelopes / 1 MiB with one journal sync.
    /// Retains per-request revision, Undo and durable deduplication boundaries.
    /// A crash can recover a complete prefix; this is not a disk-atomic batch.
    pub fn request_group(
        &mut self,
        requests: &[&ProtocolRequest],
    ) -> Result<Vec<ProtocolReceipt>, StorageError> {
        self.request_group_with(requests, |_| Ok(()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{
        fs,
        path::PathBuf,
        sync::atomic::{AtomicU64, Ordering},
        time::Duration,
    };
    use threex_core::{RequestError, SessionId};
    static NEXT: AtomicU64 = AtomicU64::new(0);
    struct Temp(PathBuf);
    impl Temp {
        fn new() -> Self {
            let p = std::env::temp_dir().join(format!(
                "threex-protocol-{}-{}",
                std::process::id(),
                NEXT.fetch_add(1, Ordering::Relaxed)
            ));
            fs::create_dir(&p).unwrap();
            Self(p)
        }
    }
    impl Drop for Temp {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.0);
        }
    }
    fn command(id: u32) -> Vec<u8> {
        let mut b = vec![0; 64];
        b[..4].copy_from_slice(&1u32.to_le_bytes());
        b[4..8].copy_from_slice(&id.to_le_bytes());
        b
    }
    fn envelope(
        d: &threex_core::Document,
        s: SessionId,
        n: u64,
        expected: u64,
        commands: Vec<u8>,
    ) -> ProtocolRequest {
        ProtocolRequest {
            protocol_version: 1,
            document_id: d.document_id().unwrap(),
            session_id: s,
            sequence: n,
            action: ProtocolAction::Commit {
                expected_revision: expected,
                commands,
            },
        }
    }
    #[test]
    fn durable_receipts_survive_restart_save_compaction_and_undo() {
        let t = Temp::new();
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        let id = a.document().document_id().unwrap();
        let s = new_session_id().unwrap();
        let r = envelope(a.document(), s, 1, 0, command(1));
        assert!(!a.request(&r).unwrap().replayed);
        drop(a);
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        assert_eq!(a.document().document_id(), Some(id));
        assert_eq!(
            a.request(&r).unwrap(),
            ProtocolReceipt {
                revision: 1,
                replayed: true
            }
        );
        a.save().unwrap();
        drop(a);
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        assert!(a.request(&r).unwrap().replayed);
        let undo = ProtocolRequest {
            sequence: 2,
            action: ProtocolAction::Undo {
                expected_revision: 1,
            },
            ..r.clone()
        };
        a.request(&undo).unwrap();
        drop(a);
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        assert!(a.request(&r).unwrap().replayed);
        assert!(a.request(&undo).unwrap().replayed);
        assert!(a.document().scene().is_empty());
        assert_eq!(a.document().revision(), 2);
        let mut mismatch = r.clone();
        mismatch.action = ProtocolAction::Commit {
            expected_revision: 0,
            commands: command(2),
        };
        assert!(matches!(
            a.request(&mismatch),
            Err(StorageError::Request(RequestError::Mismatch))
        ));
        let other = Temp::new();
        let b = AutosaveDocument::open(DocumentStore::new(&other.0)).unwrap();
        mismatch.document_id = b.document().document_id().unwrap();
        assert!(matches!(
            a.request(&mismatch),
            Err(StorageError::Request(RequestError::DocumentMismatch))
        ));
        let mut future = r;
        future.protocol_version = 2;
        assert!(matches!(
            a.request(&future),
            Err(StorageError::UnsupportedRequestProtocol)
        ));
    }
    #[test]
    fn eviction_watermark_noop_and_session_limits_survive_checkpoint() {
        let t = Temp::new();
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        let s = new_session_id().unwrap();
        let first = envelope(a.document(), s, 1, 0, vec![]);
        a.request(&first).unwrap();
        let receipt = a.save().unwrap();
        for n in 2..=66 {
            let r = envelope(a.document(), s, n, 0, vec![]);
            a.request(&r).unwrap();
        }
        assert_eq!(a.document().revision(), 0);
        assert!(!receipt.is_current(a.document()));
        a.save().unwrap();
        drop(a);
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        assert!(matches!(
            a.request(&first),
            Err(StorageError::Request(RequestError::Expired))
        ));
        let latest = envelope(a.document(), s, 66, 0, vec![]);
        assert!(a.request(&latest).unwrap().replayed);
        let gap = envelope(a.document(), s, 68, 0, vec![]);
        assert!(matches!(
            a.request(&gap),
            Err(StorageError::Request(RequestError::SequenceGap))
        ));
        for _ in 0..63 {
            let r = envelope(a.document(), new_session_id().unwrap(), 1, 0, vec![]);
            a.request(&r).unwrap();
        }
        let excess = envelope(a.document(), new_session_id().unwrap(), 1, 0, vec![]);
        assert!(matches!(
            a.request(&excess),
            Err(StorageError::Request(RequestError::SessionLimit))
        ));
        a.save().unwrap();
        drop(a);
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        assert!(matches!(
            a.request(&excess),
            Err(StorageError::Request(RequestError::SessionLimit))
        ));
    }
    #[test]
    fn legacy_journal_migration_creates_stable_id_without_replaying_edits_twice() {
        let t = Temp::new();
        let crc = |bytes: &[u8]| {
            let mut c = !0u32;
            for &v in bytes {
                c ^= v as u32;
                for _ in 0..8 {
                    c = (c >> 1) ^ (0xedb88320 & 0u32.wrapping_sub(c & 1));
                }
            }
            !c
        };
        let mut d = threex_core::Document::default();
        d.commit(0, &command(1)).unwrap();
        let mut old = d.checkpoint().unwrap();
        old.truncate(old.len() - 36);
        old[8..12].copy_from_slice(&1u32.to_le_bytes());
        old.extend(crc(&old).to_le_bytes());
        fs::write(t.0.join("generation-00000000000000000001.txd"), &old).unwrap();
        let mut journal = b"THREEXJ1".to_vec();
        journal.extend((old.len() as u64).to_le_bytes());
        journal.extend(&old);
        journal.extend(crc(&old).to_le_bytes());
        fs::write(t.0.join("autosave.txj"), journal).unwrap();
        let a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        let id = a.document().document_id().unwrap();
        assert_eq!(a.document().revision(), 1);
        drop(a);
        assert_eq!(
            &fs::read(t.0.join("autosave.txj")).unwrap()[..8],
            b"THREEXJ2"
        );
        let a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        assert_eq!(a.document().document_id(), Some(id));
        assert_eq!(a.document().scene().len(), 1);
    }
    #[test]
    fn worker_protocol_replays_after_restart_with_same_document_identity() {
        let t = Temp::new();
        let worker =
            JournalWorker::start(DocumentStore::new(&t.0), WorkerConfig::default()).unwrap();
        let id = worker.initial_state.document_id;
        let r = ProtocolRequest {
            protocol_version: 1,
            document_id: id,
            session_id: new_session_id().unwrap(),
            sequence: 1,
            action: ProtocolAction::Commit {
                expected_revision: 0,
                commands: command(7),
            },
        };
        let send = |worker: &JournalWorker, r: ProtocolRequest| {
            worker
                .client()
                .try_submit(WorkerRequest {
                    id: 1,
                    action: WorkerAction::Protocol(r),
                })
                .unwrap()
                .recv_timeout(Duration::from_secs(5))
                .unwrap()
        };
        assert!(matches!(
            send(&worker, r.clone()).result,
            Ok(WorkerOutcome::Protocol {
                replayed: false,
                revision: 1,
                ..
            })
        ));
        worker.shutdown().unwrap();
        let worker =
            JournalWorker::start(DocumentStore::new(&t.0), WorkerConfig::default()).unwrap();
        assert_eq!(worker.initial_state.document_id, id);
        assert!(matches!(
            send(&worker, r.clone()).result,
            Ok(WorkerOutcome::Protocol {
                replayed: true,
                revision: 1,
                ..
            })
        ));
        worker.shutdown().unwrap();
        assert_eq!(
            DocumentStore::new(&t.0)
                .load()
                .unwrap()
                .document
                .scene()
                .len(),
            1
        );
    }
    #[test]
    fn groups_match_sequential_history_and_replay_after_restart_and_compaction() {
        let t = Temp::new();
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        let mut reference =
            threex_core::Document::from_checkpoint(&a.document().checkpoint().unwrap()).unwrap();
        let session = new_session_id().unwrap();
        let other = new_session_id().unwrap();
        let first = envelope(a.document(), session, 1, 0, command(1));
        let noop = envelope(a.document(), session, 2, 1, vec![]);
        let mut child = command(2);
        child[60..64].copy_from_slice(&1u32.to_le_bytes());
        let mut update = child.clone();
        update[..4].copy_from_slice(&2u32.to_le_bytes());
        child.extend(update);
        let second = envelope(a.document(), other, 1, 1, child);
        let third = envelope(a.document(), session, 3, 2, command(3));
        let input = [&first, &first, &noop, &second, &third];
        for r in input {
            let (kind, expected, commands) = r.action.parts();
            if let threex_core::RequestPreparation::Pending(p) = reference
                .prepare_request(
                    r.document_id,
                    r.session_id,
                    r.sequence,
                    kind,
                    expected,
                    commands,
                )
                .unwrap()
            {
                reference.apply_request(p).unwrap();
            }
        }
        let mut syncs = 0;
        let results = a
            .request_group_with(&input, |stage| {
                if stage == 2 {
                    syncs += 1;
                }
                Ok(())
            })
            .unwrap();
        assert_eq!(syncs, 1);
        assert_eq!(a.document().scene().object(2).unwrap().parent, 1);
        assert_eq!(
            results
                .iter()
                .map(|r| (r.revision, r.replayed))
                .collect::<Vec<_>>(),
            vec![(1, false), (1, true), (1, false), (2, false), (3, false)]
        );
        assert_eq!(
            a.document().checkpoint().unwrap(),
            reference.checkpoint().unwrap()
        );
        assert!(
            a.request_group_with(&input, |_| panic!("replays must not write or sync"))
                .unwrap()
                .iter()
                .all(|r| r.replayed)
        );
        a.save().unwrap();
        drop(a);
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        assert!(a.request_group(&input).unwrap().iter().all(|r| r.replayed));
        let undo = ProtocolRequest {
            sequence: 4,
            action: ProtocolAction::Undo {
                expected_revision: 3,
            },
            ..first.clone()
        };
        a.request(&undo).unwrap();
        assert!(a.document().scene().object(3).is_none());
        assert!(a.request_group(&input).unwrap().iter().all(|r| r.replayed));
        assert_eq!(a.document().revision(), 4);
    }
    #[test]
    fn invalid_groups_reject_before_io_and_noop_groups_sync_once() {
        let t = Temp::new();
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        let session = new_session_id().unwrap();
        let first = envelope(a.document(), session, 1, 0, command(1));
        let bad = envelope(a.document(), session, 2, 0, command(2));
        let before = fs::read(t.0.join("autosave.txj")).unwrap();
        assert!(
            a.request_group_with(&[&first, &bad], |_| panic!("invalid group performed IO"))
                .is_err()
        );
        assert_eq!(a.document().revision(), 0);
        assert_eq!(a.document().session_sequence(session), None);
        assert_eq!(fs::read(t.0.join("autosave.txj")).unwrap(), before);
        let noop1 = envelope(a.document(), session, 1, 0, vec![]);
        let noop2 = envelope(a.document(), session, 2, 0, vec![]);
        let mut syncs = 0;
        a.request_group_with(&[&noop1, &noop2], |at| {
            if at == 2 {
                syncs += 1;
            }
            Ok(())
        })
        .unwrap();
        assert_eq!(syncs, 1);
        assert_eq!(a.document().revision(), 0);
        assert_eq!(a.document().session_sequence(session), Some(2));
        assert!(fs::read(t.0.join("autosave.txj")).unwrap().len() > before.len());
        let mut mismatch = noop1.clone();
        mismatch.action = first.action.clone();
        assert!(matches!(
            a.request_group(&[&mismatch]),
            Err(StorageError::Request(RequestError::Mismatch))
        ));
        let mut unsupported = noop1.clone();
        unsupported.protocol_version = 2;
        assert!(matches!(
            a.request_group(&[&unsupported]),
            Err(StorageError::UnsupportedRequestProtocol)
        ));
        let barrier = ProtocolRequest {
            sequence: 3,
            action: ProtocolAction::Undo {
                expected_revision: 0,
            },
            ..noop1.clone()
        };
        assert!(a.request_group(&[&barrier]).is_err());
        assert!(a.request_group(&[]).unwrap().is_empty());
        drop(a);
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        assert!(
            a.request_group(&[&noop1, &noop2])
                .unwrap()
                .iter()
                .all(|r| r.replayed)
        );
    }
    fn four(a: &AutosaveDocument) -> Vec<ProtocolRequest> {
        let session = SessionId::from_bytes([19; 16]).unwrap();
        (0..4)
            .map(|i| envelope(a.document(), session, i + 1, i, command(i as u32 + 1)))
            .collect()
    }
    #[test]
    fn every_group_suffix_cut_and_corruption_preserves_edit_receipt_prefix() {
        let t = Temp::new();
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        let path = t.0.join("autosave.txj");
        let base = fs::metadata(&path).unwrap().len() as usize;
        let requests = four(&a);
        a.request_group(&requests.iter().collect::<Vec<_>>())
            .unwrap();
        drop(a);
        let full = fs::read(&path).unwrap();
        let frame = (full.len() - base) / 4;
        for end in base..=full.len() {
            fs::write(&path, &full[..end]).unwrap();
            let d = DocumentStore::new(&t.0).load().unwrap().document;
            let count = (end - base) / frame;
            assert_eq!(d.revision(), count as u64);
            assert_eq!(d.scene().len(), count);
            assert_eq!(
                d.session_sequence(requests[0].session_id),
                if count == 0 { None } else { Some(count as u64) }
            );
        }
        for at in base + 3 * frame..full.len() {
            let mut damaged = full.clone();
            damaged[at] ^= 1;
            fs::write(&path, damaged).unwrap();
            let d = DocumentStore::new(&t.0).load().unwrap().document;
            assert_eq!(d.revision(), 3);
            assert_eq!(d.session_sequence(requests[0].session_id), Some(3));
        }
        for count in 0..=4 {
            fs::write(&path, &full[..base + count * frame]).unwrap();
            let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
            let results = a
                .request_group(&requests.iter().collect::<Vec<_>>())
                .unwrap();
            for (index, r) in results.iter().enumerate() {
                assert_eq!(r.replayed, index < count);
            }
            assert_eq!(a.document().revision(), 4);
            assert_eq!(a.document().scene().len(), 4);
            a.save().unwrap();
            drop(a);
            // Remove generations so the next artificial truncation tests journal-prefix recovery.
            for entry in fs::read_dir(&t.0).unwrap() {
                let entry = entry.unwrap();
                if entry
                    .file_name()
                    .to_string_lossy()
                    .starts_with("generation-")
                {
                    fs::remove_file(entry.path()).unwrap();
                }
            }
        }
    }
    #[test]
    fn group_write_failures_publish_nothing_and_same_owner_retry_is_safe() {
        for stage in 0..3 {
            let t = Temp::new();
            let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
            let requests = four(&a);
            assert!(
                a.request_group_with(&requests.iter().collect::<Vec<_>>(), |at| if at == stage {
                    Err(std::io::Error::other("injected failure"))
                } else {
                    Ok(())
                })
                .is_err()
            );
            assert_eq!(a.document().revision(), 0);
            assert_eq!(a.document().request_generation(), 0);
            let results = a
                .request_group(&requests.iter().collect::<Vec<_>>())
                .unwrap();
            assert!(results.iter().all(|r| !r.replayed));
            drop(a);
            let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
            assert!(
                a.request_group(&requests.iter().collect::<Vec<_>>())
                    .unwrap()
                    .iter()
                    .all(|r| r.replayed)
            );
            assert_eq!(a.document().scene().len(), 4);
        }
    }
    #[test]
    fn process_exit_in_protocol_group_recovers_and_deduplicates_prefix() {
        if let Ok(path) = std::env::var("THREEX_PROTOCOL_GROUP_EXIT") {
            let stage = std::env::var("THREEX_PROTOCOL_GROUP_STAGE")
                .unwrap()
                .parse::<u8>()
                .unwrap();
            let mut a = AutosaveDocument::open(DocumentStore::new(path)).unwrap();
            let requests = four(&a);
            a.request_group_with(&requests.iter().collect::<Vec<_>>(), |at| {
                if at == stage {
                    std::process::exit(81)
                }
                Ok(())
            })
            .unwrap();
            panic!("missed exit");
        }
        for stage in 0..3 {
            let t = Temp::new();
            let status=std::process::Command::new(std::env::current_exe().unwrap()).args(["--exact","protocol::tests::process_exit_in_protocol_group_recovers_and_deduplicates_prefix"])
                .env("THREEX_PROTOCOL_GROUP_EXIT",&t.0).env("THREEX_PROTOCOL_GROUP_STAGE",stage.to_string()).stdout(std::process::Stdio::null()).stderr(std::process::Stdio::null()).status().unwrap();
            assert_eq!(status.code(), Some(81));
            let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
            let count = if stage == 0 { 2 } else { 4 };
            assert_eq!(a.document().revision(), count);
            let requests = four(&a);
            let results = a
                .request_group(&requests.iter().collect::<Vec<_>>())
                .unwrap();
            for (i, r) in results.iter().enumerate() {
                assert_eq!(r.replayed, (i as u64) < count);
            }
            assert_eq!(a.document().scene().len(), 4);
            a.save().unwrap();
            drop(a);
            let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
            assert!(
                a.request_group(&requests.iter().collect::<Vec<_>>())
                    .unwrap()
                    .iter()
                    .all(|r| r.replayed)
            );
        }
    }
    #[test]
    fn journal_sync_calls_reduce_from_request_count_to_one() {
        for size in [1, 8, 32] {
            let before = Temp::new();
            let after = Temp::new();
            let mut sequential = AutosaveDocument::open(DocumentStore::new(&before.0)).unwrap();
            let mut grouped = AutosaveDocument::open(DocumentStore::new(&after.0)).unwrap();
            let session = new_session_id().unwrap();
            let requests = (0..size)
                .map(|i| envelope(grouped.document(), session, i + 1, i, command(i as u32 + 1)))
                .collect::<Vec<_>>();
            let mut single_syncs = 0;
            for r in &requests {
                let mut r = r.clone();
                r.document_id = sequential.document().document_id().unwrap();
                sequential
                    .request_with(&r, |stage| {
                        if stage == 2 {
                            single_syncs += 1;
                        }
                        Ok(())
                    })
                    .unwrap();
            }
            let mut group_syncs = 0;
            grouped
                .request_group_with(&requests.iter().collect::<Vec<_>>(), |stage| {
                    if stage == 2 {
                        group_syncs += 1;
                    }
                    Ok(())
                })
                .unwrap();
            assert_eq!(single_syncs, size);
            assert_eq!(group_syncs, 1);
            assert_eq!(
                sequential.document().snapshot(),
                grouped.document().snapshot()
            );
            grouped
                .request_group_with(&requests.iter().collect::<Vec<_>>(), |_| {
                    panic!("replay performed IO")
                })
                .unwrap();
            drop(grouped);
            let loaded = DocumentStore::new(&after.0).load().unwrap();
            assert_eq!(loaded.journal_transactions, size as usize);
            assert_eq!(loaded.document.session_sequence(session), Some(size));
        }
    }
}
