use crate::*;
use threex_core::{DocumentId, SessionId};
pub const REQUEST_PROTOCOL_VERSION: u32 = 1;
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ProtocolAction {
    Commit {
        expected_revision: u64,
        commands: Vec<u8>,
    },
    Undo {
        expected_revision: u64,
    },
    Redo {
        expected_revision: u64,
    },
}
impl ProtocolAction {
    pub(crate) fn parts(&self) -> (u8, u64, &[u8]) {
        match self {
            Self::Commit {
                expected_revision,
                commands,
            } => (1, *expected_revision, commands),
            Self::Undo { expected_revision } => (2, *expected_revision, &[]),
            Self::Redo { expected_revision } => (3, *expected_revision, &[]),
        }
    }
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ProtocolRequest {
    pub protocol_version: u32,
    pub document_id: DocumentId,
    pub session_id: SessionId,
    pub sequence: u64,
    pub action: ProtocolAction,
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ProtocolReceipt {
    pub revision: u64,
    pub replayed: bool,
}
impl AutosaveDocument {
    pub fn request(&mut self, request: &ProtocolRequest) -> Result<ProtocolReceipt, StorageError> {
        self.request_with(request, |_| Ok(()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{
        fs,
        path::PathBuf,
        sync::atomic::{AtomicU64, Ordering},
        time::Duration,
    };
    use threex_core::{RequestError, SessionId};
    static NEXT: AtomicU64 = AtomicU64::new(0);
    struct Temp(PathBuf);
    impl Temp {
        fn new() -> Self {
            let p = std::env::temp_dir().join(format!(
                "threex-protocol-{}-{}",
                std::process::id(),
                NEXT.fetch_add(1, Ordering::Relaxed)
            ));
            fs::create_dir(&p).unwrap();
            Self(p)
        }
    }
    impl Drop for Temp {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.0);
        }
    }
    fn command(id: u32) -> Vec<u8> {
        let mut b = vec![0; 64];
        b[..4].copy_from_slice(&1u32.to_le_bytes());
        b[4..8].copy_from_slice(&id.to_le_bytes());
        b
    }
    fn envelope(
        d: &threex_core::Document,
        s: SessionId,
        n: u64,
        expected: u64,
        commands: Vec<u8>,
    ) -> ProtocolRequest {
        ProtocolRequest {
            protocol_version: 1,
            document_id: d.document_id().unwrap(),
            session_id: s,
            sequence: n,
            action: ProtocolAction::Commit {
                expected_revision: expected,
                commands,
            },
        }
    }
    #[test]
    fn durable_receipts_survive_restart_save_compaction_and_undo() {
        let t = Temp::new();
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        let id = a.document().document_id().unwrap();
        let s = new_session_id().unwrap();
        let r = envelope(a.document(), s, 1, 0, command(1));
        assert!(!a.request(&r).unwrap().replayed);
        drop(a);
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        assert_eq!(a.document().document_id(), Some(id));
        assert_eq!(
            a.request(&r).unwrap(),
            ProtocolReceipt {
                revision: 1,
                replayed: true
            }
        );
        a.save().unwrap();
        drop(a);
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        assert!(a.request(&r).unwrap().replayed);
        let undo = ProtocolRequest {
            sequence: 2,
            action: ProtocolAction::Undo {
                expected_revision: 1,
            },
            ..r.clone()
        };
        a.request(&undo).unwrap();
        drop(a);
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        assert!(a.request(&r).unwrap().replayed);
        assert!(a.request(&undo).unwrap().replayed);
        assert!(a.document().scene().is_empty());
        assert_eq!(a.document().revision(), 2);
        let mut mismatch = r.clone();
        mismatch.action = ProtocolAction::Commit {
            expected_revision: 0,
            commands: command(2),
        };
        assert!(matches!(
            a.request(&mismatch),
            Err(StorageError::Request(RequestError::Mismatch))
        ));
        let other = Temp::new();
        let b = AutosaveDocument::open(DocumentStore::new(&other.0)).unwrap();
        mismatch.document_id = b.document().document_id().unwrap();
        assert!(matches!(
            a.request(&mismatch),
            Err(StorageError::Request(RequestError::DocumentMismatch))
        ));
        let mut future = r;
        future.protocol_version = 2;
        assert!(matches!(
            a.request(&future),
            Err(StorageError::UnsupportedRequestProtocol)
        ));
    }
    #[test]
    fn eviction_watermark_noop_and_session_limits_survive_checkpoint() {
        let t = Temp::new();
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        let s = new_session_id().unwrap();
        let first = envelope(a.document(), s, 1, 0, vec![]);
        a.request(&first).unwrap();
        let receipt = a.save().unwrap();
        for n in 2..=66 {
            let r = envelope(a.document(), s, n, 0, vec![]);
            a.request(&r).unwrap();
        }
        assert_eq!(a.document().revision(), 0);
        assert!(!receipt.is_current(a.document()));
        a.save().unwrap();
        drop(a);
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        assert!(matches!(
            a.request(&first),
            Err(StorageError::Request(RequestError::Expired))
        ));
        let latest = envelope(a.document(), s, 66, 0, vec![]);
        assert!(a.request(&latest).unwrap().replayed);
        let gap = envelope(a.document(), s, 68, 0, vec![]);
        assert!(matches!(
            a.request(&gap),
            Err(StorageError::Request(RequestError::SequenceGap))
        ));
        for _ in 0..63 {
            let r = envelope(a.document(), new_session_id().unwrap(), 1, 0, vec![]);
            a.request(&r).unwrap();
        }
        let excess = envelope(a.document(), new_session_id().unwrap(), 1, 0, vec![]);
        assert!(matches!(
            a.request(&excess),
            Err(StorageError::Request(RequestError::SessionLimit))
        ));
        a.save().unwrap();
        drop(a);
        let mut a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        assert!(matches!(
            a.request(&excess),
            Err(StorageError::Request(RequestError::SessionLimit))
        ));
    }
    #[test]
    fn legacy_journal_migration_creates_stable_id_without_replaying_edits_twice() {
        let t = Temp::new();
        let crc = |bytes: &[u8]| {
            let mut c = !0u32;
            for &v in bytes {
                c ^= v as u32;
                for _ in 0..8 {
                    c = (c >> 1) ^ (0xedb88320 & 0u32.wrapping_sub(c & 1));
                }
            }
            !c
        };
        let mut d = threex_core::Document::default();
        d.commit(0, &command(1)).unwrap();
        let mut old = d.checkpoint().unwrap();
        old.truncate(old.len() - 36);
        old[8..12].copy_from_slice(&1u32.to_le_bytes());
        old.extend(crc(&old).to_le_bytes());
        fs::write(t.0.join("generation-00000000000000000001.txd"), &old).unwrap();
        let mut journal = b"THREEXJ1".to_vec();
        journal.extend((old.len() as u64).to_le_bytes());
        journal.extend(&old);
        journal.extend(crc(&old).to_le_bytes());
        fs::write(t.0.join("autosave.txj"), journal).unwrap();
        let a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        let id = a.document().document_id().unwrap();
        assert_eq!(a.document().revision(), 1);
        drop(a);
        assert_eq!(
            &fs::read(t.0.join("autosave.txj")).unwrap()[..8],
            b"THREEXJ2"
        );
        let a = AutosaveDocument::open(DocumentStore::new(&t.0)).unwrap();
        assert_eq!(a.document().document_id(), Some(id));
        assert_eq!(a.document().scene().len(), 1);
    }
    #[test]
    fn worker_protocol_replays_after_restart_with_same_document_identity() {
        let t = Temp::new();
        let worker =
            JournalWorker::start(DocumentStore::new(&t.0), WorkerConfig::default()).unwrap();
        let id = worker.initial_state.document_id;
        let r = ProtocolRequest {
            protocol_version: 1,
            document_id: id,
            session_id: new_session_id().unwrap(),
            sequence: 1,
            action: ProtocolAction::Commit {
                expected_revision: 0,
                commands: command(7),
            },
        };
        let send = |worker: &JournalWorker, r: ProtocolRequest| {
            worker
                .client()
                .try_submit(WorkerRequest {
                    id: 1,
                    action: WorkerAction::Protocol(r),
                })
                .unwrap()
                .recv_timeout(Duration::from_secs(5))
                .unwrap()
        };
        assert!(matches!(
            send(&worker, r.clone()).result,
            Ok(WorkerOutcome::Protocol {
                replayed: false,
                revision: 1,
                ..
            })
        ));
        worker.shutdown().unwrap();
        let worker =
            JournalWorker::start(DocumentStore::new(&t.0), WorkerConfig::default()).unwrap();
        assert_eq!(worker.initial_state.document_id, id);
        assert!(matches!(
            send(&worker, r.clone()).result,
            Ok(WorkerOutcome::Protocol {
                replayed: true,
                revision: 1,
                ..
            })
        ));
        worker.shutdown().unwrap();
        assert_eq!(
            DocumentStore::new(&t.0)
                .load()
                .unwrap()
                .document
                .scene()
                .len(),
            1
        );
    }
}
