//! Persistent identifiers and bounded request receipts, independent of hosts.
use crate::{Document, DocumentError, PreparedTransaction};
use std::{
    collections::{BTreeMap, VecDeque},
    fmt,
    str::FromStr,
};
macro_rules! identifier {
    ($name:ident) => {
        #[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
        pub struct $name([u8; 16]);
        impl $name {
            pub fn from_bytes(bytes: [u8; 16]) -> Option<Self> {
                (bytes != [0; 16]).then_some(Self(bytes))
            }
            pub fn bytes(self) -> [u8; 16] {
                self.0
            }
        }
        impl fmt::Display for $name {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                for b in self.0 {
                    write!(f, "{b:02x}")?
                }
                Ok(())
            }
        }
        impl FromStr for $name {
            type Err = ();
            fn from_str(s: &str) -> Result<Self, ()> {
                if s.len() != 32 || !s.is_ascii() {
                    return Err(());
                }
                let mut b = [0; 16];
                for (i, v) in b.iter_mut().enumerate() {
                    *v = u8::from_str_radix(&s[i * 2..i * 2 + 2], 16).map_err(|_| ())?
                }
                Self::from_bytes(b).ok_or(())
            }
        }
    };
}
identifier!(DocumentId);
identifier!(SessionId);
#[derive(Debug, PartialEq, Eq)]
pub enum RequestError {
    DocumentMismatch,
    InvalidSequence,
    SequenceGap,
    Expired,
    Mismatch,
    SessionLimit,
    Edit(DocumentError),
}
#[derive(Clone)]
pub(crate) struct Receipt {
    pub session: SessionId,
    pub sequence: u64,
    pub kind: u8,
    pub expected: u64,
    pub revision: u64,
    pub commands: Vec<u8>,
}
#[derive(Default)]
pub(crate) struct RequestLedger {
    pub sessions: BTreeMap<SessionId, u64>,
    pub receipts: VecDeque<Receipt>,
    pub bytes: usize,
}
pub enum RequestPreparation {
    Replay(u64),
    Pending(PreparedRequest),
}
pub struct PreparedRequest {
    edit: PreparedTransaction,
    receipt: Receipt,
    prior: u64,
    document: DocumentId,
}
impl PreparedRequest {
    pub fn revision(&self) -> u64 {
        self.receipt.revision
    }
}
impl Document {
    pub fn session_sequence(&self, session: SessionId) -> Option<u64> {
        self.ledger.sessions.get(&session).copied()
    }
    pub fn request_generation(&self) -> u128 {
        self.ledger.sessions.values().map(|&n| n as u128).sum()
    }
    pub fn document_id(&self) -> Option<DocumentId> {
        self.id
    }
    /// Hosts bind draft/legacy documents once, before exposing their persistent identity.
    pub fn bind_document_id(&mut self, id: DocumentId) -> Result<(), RequestError> {
        if self.id.is_some_and(|old| old != id) {
            return Err(RequestError::DocumentMismatch);
        }
        self.id = Some(id);
        Ok(())
    }
    pub fn prepare_request(
        &self,
        document: DocumentId,
        session: SessionId,
        sequence: u64,
        kind: u8,
        expected: u64,
        commands: &[u8],
    ) -> Result<RequestPreparation, RequestError> {
        if self.id != Some(document) {
            return Err(RequestError::DocumentMismatch);
        }
        if sequence == 0 {
            return Err(RequestError::InvalidSequence);
        }
        let prior = self.ledger.sessions.get(&session).copied().unwrap_or(0);
        if sequence <= prior {
            let Some(receipt) = self
                .ledger
                .receipts
                .iter()
                .find(|r| r.session == session && r.sequence == sequence)
            else {
                return Err(RequestError::Expired);
            };
            if receipt.kind != kind || receipt.expected != expected || receipt.commands != commands
            {
                return Err(RequestError::Mismatch);
            }
            return Ok(RequestPreparation::Replay(receipt.revision));
        }
        if prior.checked_add(1) != Some(sequence) {
            return Err(RequestError::SequenceGap);
        }
        if prior == 0 && self.ledger.sessions.len() >= 64 {
            return Err(RequestError::SessionLimit);
        }
        let edit = match kind {
            1 => self.prepare_commit(expected, commands),
            2 if commands.is_empty() => self.prepare_undo(expected),
            3 if commands.is_empty() => self.prepare_redo(expected),
            _ => {
                return Err(RequestError::Edit(DocumentError::InvalidCommand(
                    "Unknown request kind".into(),
                )));
            }
        }
        .map_err(RequestError::Edit)?;
        let receipt = Receipt {
            session,
            sequence,
            kind,
            expected,
            revision: edit.revision(),
            commands: commands.to_vec(),
        };
        Ok(RequestPreparation::Pending(PreparedRequest {
            edit,
            receipt,
            prior,
            document,
        }))
    }
    pub fn apply_request(&mut self, prepared: PreparedRequest) -> Result<u64, RequestError> {
        if self.id != Some(prepared.document) {
            return Err(RequestError::DocumentMismatch);
        }
        if self
            .ledger
            .sessions
            .get(&prepared.receipt.session)
            .copied()
            .unwrap_or(0)
            != prepared.prior
        {
            return Err(RequestError::Expired);
        }
        let revision = self
            .apply_prepared(prepared.edit)
            .map_err(RequestError::Edit)?;
        self.ledger
            .sessions
            .insert(prepared.receipt.session, prepared.receipt.sequence);
        self.ledger.bytes += prepared.receipt.commands.len();
        self.ledger.receipts.push_back(prepared.receipt);
        while self.ledger.receipts.len() > 64 || self.ledger.bytes > 8 * 1024 * 1024 {
            self.ledger.bytes -= self.ledger.receipts.pop_front().unwrap().commands.len();
        }
        Ok(revision)
    }
}
